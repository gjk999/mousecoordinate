/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package touch;

/**
 *
 * @author Common
 */
public class CoordArray {
    private Double key;
    private Double value;
    
    public CoordArray(){
        
    }
    public CoordArray(Double aKey, Double aValue){
        key = aKey;
        value = aValue;
    }   
    public void setX(double key){this.key = key;}
    public void setY(double value){this.value = value;}
    public Double getX()   { return key; }
    public Double getY() { return value; }
}
