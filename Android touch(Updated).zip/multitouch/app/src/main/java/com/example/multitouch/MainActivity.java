package com.example.multitouch;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.AsyncTask;
import android.text.format.Formatter;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Scanner;

public class MainActivity extends Activity implements onSomeEventListener {
    static Socket s;
    static ServerSocket ss;
    static DataInputStream in;
    static DataOutputStream out;
    static InputStreamReader isr;
    static BufferedReader br;
    static int line = 0;
    static String rec;
    static String IP_address;
    ArrayList<CoordArray> startCoord = new ArrayList<>();
    ArrayList<CoordArray> endCoord = new ArrayList<>();
    ArrayList<CoordArray> clickCoord = new ArrayList<>();
    ArrayList<CoordArray> drawCoord = new ArrayList<>();


    float xAxis = 0f;
    float yAxis = 0f;

    float lastXAxis = 0f;
    float lastYAxis = 0f;

    static TextView tv1;
    LinearLayout rl;

    @Override
    public void setText1(String data) {
        tv1.setText(data);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        rl=(LinearLayout) findViewById(R.id.rl);
        tv1 = (TextView) findViewById(R.id.textView);
        Button btn = (Button) this.findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                IP_address = NetwordDetect();
                Log.d("Test","Test");
                Log.d("Test",IP_address);
            }
        });
        tv1.setText("Test");
        new MyTask( ).execute();
//        MainActivity.this.startService(new Intent(MainActivity.this, MyService.class));
    }

        public void readFile(){
            try{
                File start = new File("/Internal Storage/Download/startCoord.txt");
                File end = new File("/Internal Storage/Download/endCoord.txt");
                File click1 = new File("/Internal Storage/Download/clickCoord.txt");
                File draw1 = new File("/Internal Storage/Download/drawCoord.txt");
                Scanner scstart = new Scanner(start);
                Scanner scend = new Scanner(end);
                Scanner scclick = new Scanner(click1);
                Scanner scdraw = new Scanner(draw1);

                while(scstart.hasNextLine()){
                    String data = scstart.nextLine();
                    String[] ar = data.split(":");
                    CoordArray ar1 = new CoordArray(Double.parseDouble(ar[0]),Double.parseDouble(ar[1]));
                    startCoord.add(ar1);
                }

                scstart.close();
            } catch(FileNotFoundException fn){  
                fn.printStackTrace();
            }

        }

        public void writeToFile(String data){
            File path = new File(MainActivity.this.getFilesDir(),"");
            if(!path.exists()){
                path.mkdir();
            }
            try{
                File file = new File(path, "");
                FileWriter write = new FileWriter(file);
                write.append(data);
                write.flush();
                write.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        private class MyTask extends AsyncTask<Void,Void, Void>{//AsyncTask
            String msg = "";

            @Override
            protected Void doInBackground(Void... voids) {
                try
                {
                    ss = new ServerSocket(8081);
                    Log.d("test","test");
                    while(true)
                    {
                        s = ss.accept();
                        Log.d("Test","Test Connected");
                        InputStream is = s.getInputStream();
                        in = new DataInputStream(is);

                        msg = in.readUTF();

                        Log.d("Test",msg);

                        out.close();
                        in.close();
                        s.close();
                        ss.close();
                    }
                } catch(IOException e)
                {
                    e.printStackTrace();
                } catch(Exception ex){
                    ex.printStackTrace();
                }
                return null;
            }
            protected void onPostExecute(Void aVoid){
                tv1.setText(msg);
                super.onPostExecute(aVoid);
            }
        }

        public static class MyService extends IntentService  {//intent
            onSomeEventListener ist = null;
            String msg = "";
            public MyService(){
                super("MyService");
            }

            public MyService(onSomeEventListener event){
                super("MyService");
                ist = event;
            }

            @SuppressLint("WrongThread")
            @Override
            protected void onHandleIntent(@Nullable Intent intent) {
                line = 0;
                try
                {
                    ss = new ServerSocket(8081);
                    Log.d("test","test");
                    while(true)
                    {
                        s = ss.accept();
                        Log.d("Test","Test Connected");
                        InputStream is = s.getInputStream();
                        in = new DataInputStream(is);

                        msg = in.readUTF();

                        Log.d("Test",msg);
//                        ist.setText1(msg);


                        out.close();
                        in.close();
                        s.close();
                        ss.close();
                    }
                } catch(IOException e)
                {
                    e.printStackTrace();
                } catch(Exception ex){
                    ex.printStackTrace();
                }
            }

        }
    private String NetwordDetect() {
        String IPaddress = "";
        boolean WIFI = false;
        boolean MOBILE = false;
        ConnectivityManager CM = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo[] networkInfo = CM.getAllNetworkInfo();
        for (NetworkInfo netInfo : networkInfo) {

            if (netInfo.getTypeName().equalsIgnoreCase("WIFI"))

                if (netInfo.isConnected())

                    WIFI = true;

            if (netInfo.getTypeName().equalsIgnoreCase("MOBILE"))

                if (netInfo.isConnected())

                    MOBILE = true;
        }
        if(WIFI == true)
        {
            IPaddress = GetDeviceipWiFiData();
        }
        if(MOBILE == true)
        {
            IPaddress = GetDeviceipMobileData();
        }
        return IPaddress;
    }
    public String GetDeviceipMobileData(){
        try {
            for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
                 ((Enumeration) en).hasMoreElements();) {
                NetworkInterface networkinterface = en.nextElement();
                for (Enumeration<InetAddress> enumIpAddr = networkinterface.getInetAddresses(); enumIpAddr.hasMoreElements();) {
                    InetAddress inetAddress = enumIpAddr.nextElement();
                    if (!inetAddress.isLoopbackAddress()) {
                        return inetAddress.getHostAddress().toString();
                    }
                }
            }
        } catch (Exception ex) {
        }
        return null;
    }

    public String GetDeviceipWiFiData()
    {
        WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        @SuppressWarnings("deprecation")
        String ip = Formatter.formatIpAddress(wm.getConnectionInfo().getIpAddress());
        return ip;
    }
}

interface onSomeEventListener{
    void setText1(String data);
}